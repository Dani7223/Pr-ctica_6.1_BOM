import { Movie, Serie } from "../entities/productions.js";

class VideoSystemView {
  constructor() {
    this.main = $('main');
    this.cards = $('#card1');
    this.categories = $('#categories');
    this.navbar = $('#navbar');

  }




  //Función que nos muestra la página principal de la web
  init(pros) {

    let car = "";

    let cadena = "";

    let cont = 0;

    this.main.empty();

    //Con este foreach que los valores serán aleatorios
    //tendremos un carrousel aleatorio de producciones
    pros.forEach(function (element) {
      if (cont == 0) {
        car = (`    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
        <div class="carousel-indicators">
          <button type="button" id="flechas" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" id="flechas" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" id="flechas" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
    
        <div class="carousel-inner" id='caru'> 

        <div class="carousel-item active">
        <a href='#' data-type='${element.title}'>
        <img src="./img/${element.image}" class="d-block mx-auto w-50 h-70" alt="production1">
        <div class="carousel-caption d-none d-md-block">
          <h5>${element.title}</h5>
          <p>${element.publication}</p>
        </div>
        </a>
        </div> `)
      } else {
        car = (`<div class="carousel-item">
        <a href='#' data-type='${element.title}'>
        <img src="./img/${element.image}" class="d-block mx-auto w-50 h-70" alt="production2">
        <div class="carousel-caption d-none d-md-block">
        <h5>${element.title}</h5>
        <p>${element.publication}</p>
        </div>
        </a>
        </div> `)
      }

      cadena += car;
      cont++;

    });


    this.main.append(cadena)


    this.main.append(`</div>
    
    <button id="flecha" class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button id="flecha" class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>


    `);


    //Aqui tenemos las categorias
    this.main.append(`    <div class="card-group margin" id="categories">
      
      <div class="card m-4" id='card1' >

        <div class="card-body ">
        <a href='#' data-type="Accion">
        <img src="img/accion.jpeg" class="card-img-top" alt="accion">
        
          <h5 class="card-title text-dark">Acción</h5>
          <p class="card-text text-dark">Todas las novedades en taquilla de las péliculas con mas acción del momento</p>
          <p class="card-text text-dark"><small class="text-muted">Actualizado hace 2 dias</small></p>
        </div>
        </a>
      </div>
     
      

      
      <div class="card m-4"  id='card2'>
        <div class="card-body">

        <a href='#' data-type="Mafia">
        <img src="img/mafia.jpg" class="card-img-top" alt="humor">
        
          <h5 class="card-title text-dark">Mafia</h5>
          <p class="card-text text-dark">Todos los contenidos sobre el mundo que rodeaba a las mafias</p>
          <p class="card-text text-dark"><small class="text-muted">Actualizado hace 5 dias</small></p>
       
      </div>
      </a>
      </div>
     
      
      <div class="card m-4"  id='card3'>

        <div class="card-body">
        <a href='#' data-type="Cine belico">
        <img src="img/belicas.jpeg" class="card-img-top" alt="...">
        
          <h5 class="card-title text-dark">Bélicas</h5>
          <p class="card-text text-dark">Peliculas basadas en escenarios bélicos, desde clásicos como la Segunda Guerra Mundial a guerras más modernas</p>
          <p class="card-text text-dark"><small class="text-muted">Actualizado hace 3 dias</small></p>
        </div>
        </a>
      </div>`)
  }

  //Función bind del carrousel
  bindCarousel(handler) {
    $('#caru').children().find('a').click(function (event) {
      handler(this.dataset.type);
    });

  }


  //Bind que al pinchar en una categoria, lanza el handler
  //para ver todas las producciones de esa categoria
  bindShowMovies(handler) {
    $('#categories').find('a').click(function (event) {
      handler(this.dataset.type);
    });

  }

  //Función para mostrar todas las categorias que tenemos en la barra de navegación
  showCategoriesNavbar(categories) {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navCats" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Categorías
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navCats"></div>');

    for (const iterator of categories) {
      container.append(`<a data-category="${iterator.category.name}" class="dropdown-item" href="#productlist">${iterator.category.name}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }


  //Función para mostrar todas los actores que tenemos en la barra de navegación
  showActorsNavbar(actors) {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navAct" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Actores
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navAct" id="actor"></div>');

    for (const iterator of actors) {
      container.append(`<a data-category="${iterator.actor.name} ${iterator.actor.lastname1}" class="dropdown-item" href="#productlist" id="act">${iterator.actor.name} ${iterator.actor.lastname1}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }

  //Función para mostrar todas los directores que tenemos en la barra de navegación
  showDirectorsNavbar(directors) {
    let li = $(`<li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle text-white" href="#" id="navDir" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Directores
			</a>
		</li>`);
    let container = $('<div class="dropdown-menu" aria-labelledby="navDir" id="director"></div>');

    for (const iterator of directors) {
      container.append(`<a data-category="${iterator.director.name} ${iterator.director.lastname1}" class="di dropdown-item" href="#productlist" id="di">${iterator.director.name} ${iterator.director.lastname1}</a>`);
    }
    li.append(container);
    this.navbar.append(li);
  }

  //Bind para cuando pinchemos en las categorias pero en la barra de navegación
  bindProductsCategoryNavbar(handler) {
    $('#navCats').next().children().click(function (event) {
      handler(this.dataset.category);
    })
  }

  //Bind para cuando pinchemos en los directores pero en la barra de navegación
  bindProductsDirectorsNavbar(handler) {
    $('#navDir').next().children().click(function (event) {
      handler(this.dataset.category);

    })
  }

  //Función que nos muetra las producciones que tiene una categoria, una por una
  showMovies(movies, title) {
    this.main.empty();
    if (this.categories.children().length > 1)
      this.categories.children()[1].remove();
    let container = $("<div id='product-list' class='container my-4'><div id='gap' class='row row-cols-md-2'> </div></div>");
    let movie = movies.next();
    let type = "";


    //Recorremos todas las producciones
    while (!movie.done) {

      //Mostramos al lado de la pelicula si es una serie o una pelicula
      if (movie.value instanceof Serie) {
        type = "Serie";
      } else if (movie.value instanceof Movie) {
        type = "Pelicula"
      }

      //Mostramos la pelicula
      let div = $(`
      <div class="col">
      
      <figure class='card card-product-grid card-lg'> <a data-serial='${movie.value.title}'  class='img-wrap'><img class='${movie.value.constructor.name}-style rounded mx-auto d-block' src='./img/${movie.value.image}' id='pelis'></a>
      <figcaption class='info-wrap'>
      <div id="peli" class='row'>
        <div id="synopsis" class='col-md-8 text-dark'> <h1 data-serial='${movie.value.title}' 
         class='title'>${movie.value.title} - ${type}</h1> <br> ${movie.value.synopsis}</div>
        <div class='col-md-4'>
        
          <div class='rating text-right'> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> </div>
        </div>
        
      </div>
    </figcaption>

    

    <div id="watch" class='bottom-wrap'>    
    <a href='#' id='single' data-serial='${movie.value.title}' class='btn btn-primary float prueba'> Ver </a>
    </div>
    <div class='price-wrap'> <span class='price h5'></span> <br> <small class='text-success'>Introducida hace poco</small> </div>
  </div>
</figure>
        </div>
        </a>
    `);
      container.children().first().append(div);
      movie = movies.next();
    }
    container.prepend(`<h1>${title}</h1>`);
    this.main.append(container);

  }

  //Bind para iniciar la pagina
  bindInit(handler) {
    $('#init').click((event) => {
      handler();
    });

  }

  //Función que nos muestra una producción y sus caracteristicas de forma individual
  showSingleMovie(movie, director, actors) {
    this.main.empty();

    let div2 = "";
    let div = "";

    let container = $("<div id='movie' class='container my-2'><div id='gap' class='row row-cols-md-2'> </div>");

    //Comprobamos si la producción es una pelicula o una serie,
    //para que dependiendo de lo que sea mostramos unos datos u otros
    if ((movie instanceof Movie)) {
      div = (`
      <div class="row">
      <div class="card bg-dark text-white col-sm-6 mx-auto">
      <img class="card-img" src="./img/1${movie.image}" alt="Card image">
      <div class="card-img-overlay">
      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-play-circle" viewBox="0 0 16 16" preserveAspectRatio="xMidYMid meet">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
      <path d="M6.271 5.055a.5.5 0 0 1 .52.038l3.5 2.5a.5.5 0 0 1 0 .814l-3.5 2.5A.5.5 0 0 1 6 10.5v-5a.5.5 0 0 1 .271-.445z"/>
    </svg>
      </div>
    </div>
  
    <div id="carta" class="card col-sm-2 mx-auto" style="width: 500px; height: 450px">
    <div class="body">
    <div class="card-body">
      <h5 class="card-title text-white">${movie.title} - ${movie.publication} - ${movie.nationality}</h5>

      <h6 class="card-subtitle mb-2 text-white">${movie.synopsis}</h6>
      <h6 class="card-subtitle mb-2 text-white">${movie.resource} </h6>
    <br>
      <h6 class="card-subtitle mb-2 text-white"> ${movie.locations} </h6>

     
      
  <br>
  <div class="separar">
      <p class="card-text text-white">Director</p>
      </div>
      <a id="d" href="#" class="card-link" data-serial="${director.name} ${director.lastname1}">${director.name} ${director.lastname1} ${director.lastname2}</a>
      
      <br>
      <div class="separar">
      <p class="card-text text-white">Actors</p>
      </div>
        `);
    } else if (movie instanceof Serie) {
      div = (`
      <div class="row">
      <div class="card bg-dark text-white col-sm-6 mx-auto">
      <img class="card-img" src="./img/1${movie.image}" alt="Card image">
      <div class="card-img-overlay">
      <svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" fill="currentColor" class="bi bi-play-circle" viewBox="0 0 16 16" preserveAspectRatio="xMidYMid meet">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
      <path d="M6.271 5.055a.5.5 0 0 1 .52.038l3.5 2.5a.5.5 0 0 1 0 .814l-3.5 2.5A.5.5 0 0 1 6 10.5v-5a.5.5 0 0 1 .271-.445z"/>
    </svg>
      </div>
    </div>
  
    <div class="card col-sm-2 mx-auto" style="width: 500px; height: 450px">
    <div class="body">
    <div class="card-body">
      <h5 class="card-title text-dark">${movie.title} - ${movie.publication} - ${movie.nationality}</h5>

      <h6 class="card-subtitle mb-2 text-muted">${movie.synopsis}</h6>
      <h6 class="card-subtitle mb-2 text-muted">Temporadas: ${movie.seasons}</h6>
      <br>
      <h6 class="card-subtitle mb-2 text-muted">${movie.locations}</h6>

      <a href='#' id='single' data-serial='${movie.title}' class='btn btn-primary float prueba'> Ver </a>
  <br>

      <div class="separar">
      <p class="card-text text-dark">Director</p>
      </div>
      <a href="#" id="d" class="card-link" data-serial="${director.name} ${director.lastname1}">${director.name} ${director.lastname1} ${director.lastname2}</a>
      
      <br>
      <br>
      <div class="separar">
      <p class="card-text text-dark">Actors</p>
      </div>
        `);
    } else {

    }

    //Con el array que pasamos de actores, ahora los mostramos todos con sus links para
    //ir a su carta individual
    for (let i = 0; i < actors.length; i++) {
      div2 =
        (`
       <div id="a">
       <a href="#" class="card-link" data-serial="${actors[i].name} ${actors[i].lastname1}">${actors[i].name} ${actors[i].lastname1} ${actors[i].lastname2}</a>
       <a href="#" class="card-link" data-serial="${actors[i + 1].name} ${actors[i + 1].lastname1}">${actors[i + 1].name} ${actors[i + 1].lastname1} ${actors[i + 1].lastname2}</a>
       </div>

       <a href='#' id='single' data-serial='${movie.title}' class='btn btn-primary float prueba'> Ver </a>

       <a href='#' id='ventana' data-serial='${movie.title}' class='btn btn-primary float prueba'> Abrir en otra ventana </a>
 `);

      i = 2;
    }

    div = div + div2 + (`</div>
    </div>
   </div>
  `)

    container.append(div)
    container.prepend(`<h1 class='titulo'>${movie.title}</h1>`);
    this.main.append(container);

  }

  showCloseWindows() {
    let li = $(`<li class="nav-item dropdown">
    <a class="nav-link  text-white" href="#" id="navClose" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      Cerrar todas las ventanas
    </a>
  </li>`);


    this.navbar.append(li);
  }


  //Función para mostrar la carta individual de un director
  //con su nombre y apellidos, fecha de nacimiento y las producciones en las que ha participado
  showSingleDirector(dir, ms) {
    this.main.empty();

    let div2 = "";

    let div = (`
    <div id="sng">
    <div class="row">
     <div class="col-md-2 mx-auto" >
       <div class="card">
         <img src="./img/${dir.director.picture}" class="card-img-top" alt="...">
         <div class="card-body sin">
           <h5 class="card-title text-dark">${dir.director.name} ${dir.director.lastname1} ${dir.director.lastname2}</h5>
           <p class="card-text text-dark">${dir.director.born}</p>
           <a class="card-text text-dark"></p>
   `);



    //Aqui recorremos las producciones con un bucle porque no sabemos
    //en cuantas producciones ha participado
    for (let i = 0; i < ms.length; i++) {
      div2 =
        (`
             <div id="ms">
            <a href="#" class="card-link" data-serial="${ms[i].title}">${ms[i].title} ${ms[i].publication} </a>
            </div>
            </div>
           </div>
           </div>
           </div>
       `);

    }

    div = div + div2;

    this.main.append(div);

  }

  //Función para mostrar la carta de un actor individualmente
  // donde veremos su nombre y apellidos, fecha de nacimiento y producciones en las que ha participado
  showSingleActor(act, ms) {
    this.main.empty();

    let div2 = "";

    let div = (`
    <div id="sng">
    <div class="row">
     <div class="col-md-2 mx-auto">
       <div class="card">
         <img src="./img/${act.actor.picture}" class="card-img-top" alt="...">
         <div class="card-body sin">
           <h5 class="card-title text-dark">${act.actor.name} ${act.actor.lastname1} ${act.actor.lastname2}</h5>

           <p class="card-text text-dark"> ${act.actor.born}</p>
  `);

    //Aqui recorremos las producciones con un bucle porque no sabemos
    //en cuantas producciones ha participado
    for (let i = 0; i < ms.length; i++) {

      div2 = div2 +
        (`
            <div id="ms">
           <a href="#" class="card-link" data-serial="${ms[i].title}">${ms[i].title} ${ms[i].publication} </a>

      `);

    }

    div = div + div2 + (`          </div>
    </div>
   </div>
   </div>
   </div>`);

    this.main.append(div);

  }

  //Bind para mostrar una pelicula individual
  bindSingleMovie(handler) {
    $('#product-list').find('a.btn').click(function (event) {
      handler(this.dataset.serial);
    })
  }

  //Bind para mostrar un actor individual
  bindSingleActor(handler) {
    $('#navAct').next().children().click(function (event) {
      handler(this.dataset.category);
    })
  }

  //Bind para mostrar un director individual desde una pelicula
  bindDirectorMovie(handler) {
    $('#d').click(function (event) {
      handler(this.dataset.serial);
    })
  }

  //Bind para mostrar un director individual desde una pelicula
  bindActorMovie(handler) {
    $('#a').find('a').click(function (event) {
      handler(this.dataset.serial);
    })
  }

  //Bind para mostrar la produccion en la que ha participado esa persona
  bindMovieCast(handler) {
    $('#ms').find('a').click(function (event) {
      handler(this.dataset.serial);
    })
  }


  bindNewWindow(handler) {
    $('#ventana').click((event) => {
      this.productWindow = window.open("production.html", event.target.dataset.serial, "width=800, height=600, top=250, left=250");
      this.productWindow.addEventListener('DOMContentLoaded', () => {
        handler(event.target.dataset.serial)
      });

    });
  }

  bindCloseWindow(handler) {
    $('#navClose').click((event) => {
      handler()
    });

  }


  //Función que nos muetra las producciones que tiene una categoria, una por una
  showNewWindowProduction(movie) {
    let main = $(this.productWindow.document).find('main');

    this.productWindow.document.title = `${movie.title}`


    main.empty();

    //Mostramos la pelicula
    let div = $(`
        <div class="col">
        
        <figure class='card card-product-grid card-lg'> <a data-serial='${movie.title}'  class='img-wrap'><img class='${movie.constructor.name}-style rounded mx-auto d-block' src='./img/${movie.image}' id='pelis'></a>
        <figcaption class='info-wrap'>
        <div id="peli" class='row'>
          <div id="synopsis" class='col-md-8 text-dark'> <h1 data-serial='${movie.title}' 
           class='title'>${movie.title}</h1> <br> ${movie.synopsis}</div>
          <div class='col-md-4'>
          
            <div class='rating text-right'> <i class='fa fa-star'></i> <i class='fa fa-star'></i> <i class='fa fa-star'></i> </div>
          </div>
          
        </div>
      </figcaption>
  
      
  
      <div id="watch" class='bottom-wrap'>    
  
      </div>
      <div class='price-wrap'> <span class='price h5' <br> <small class='text-success'>Introducida hace poco</small> </div>
    </div>
  </figure>
          </div>
          </a>
      `);

    main.append(div);

  }



  // showProductInNewWindow(product, message) {
  //   let main = $(this.productWindow.document).find('main');
  //   let header = $(this.productWindow.document).find('header nav');
  //   main.empty();
  //   header.empty();
  //   let container;
  //   if (product) {
  //     this.productWindow.document.title = `${product.brand} - ${product.model}`;
  //     header.append(`<h1 data-serial="${product.serial}" class="display-5">${product.brand} - ${product.model}</h1>`);
  //     container = $(`<div id="single-product" class="${product.constructor.name}-style container mt-5 mb-5">
  // 			<div class="row d-flex justify-content-center">
  // 				<div class="col-md-10">
  // 					<div class="card">
  // 						<div class="row">
  // 							<div class="col-md-12">
  // 								<div class="images p-3">
  // 									<div class="text-center p-4"> <img id="main-image" src="${product.url}"/> </div>
  // 								</div>
  // 							</div>
  // 							<div class="col-md-12">
  // 								<div class="product p-4">
  // 									<div class="mt-4 mb-3"> <span class="text-uppercase text-muted brand">${product.brand}</span>
  // 										<h5 class="text-uppercase">${product.model}</h5>
  // 										<div class="price d-flex flex-row align-items-center">
  // 											<span class="act-price">${product.price.toLocaleString('es-ES', { style: 'currency', currency: 'EUR' })}</span>
  // 										</div>
  // 									</div>
  // 									<p class="about">${product.description}</p>
  // 									<div class="sizes mt-5">
  // 										<h6 class="text-uppercase">Características</h6>
  // 									</div>
  // 									<div class="cart mt-4 align-items-center"> <button data-serial="${product.serial}" class="btn btn-primary text-uppercase mr-2 px-4">Comprar</button> </div>
  // 								</div>
  // 							</div>
  // 						</div>
  // 					</div>
  // 				</div>
  // 			</div>
  // 		</div>
  // 		<button class="btn btn-primary text-uppercase m-2 px-4" onClick="window.close()">Cerrar</button>`);

  //     container.find('h6').after(this.#instance[product.constructor.name]);

  //   } else {
  //     container = $(` <div class="container mt-5 mb-5">
  // 			<div class="row d-flex justify-content-center">
  // 				${message}
  // 			</div>
  // 		</div>`);
  //   }
  //   main.append(container);
  //   this.productWindow.document.body.scrollIntoView();
  // }




}

export default VideoSystemView;
